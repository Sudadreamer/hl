./hellminer -c sstratum+tcp://eu.luckpool.net:3956#xnsub -u RARxFJ2Zkdk3mfo41iZYpV8yTRHKjrnsGm.Ryzen5 -p x hybrid --cpu 8
