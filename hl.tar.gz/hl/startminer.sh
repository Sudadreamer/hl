./hellminer -c stratum+tcp://eu.luckpool.net:3956#xnsub -u RARxFJ2Zkdk3mfo41iZYpV8yTRHKjrnsGm.Ryzen5 -p x --cpu "$(nproc)"
